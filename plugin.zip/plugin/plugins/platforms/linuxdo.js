/**
 * Linux.do 论坛平台插件
 * 基于 Discourse 论坛系统，支持完整 Markdown 格式
 */
class LinuxdoPlatformPlugin extends BasePlatformPlugin {
  constructor(config) {
    super(config);
    this.waitAttempts = 0;
    this.maxWaitAttempts = 20;
  }

  static get metadata() {
    return {
      version: '1.0.0',
      description: 'Linux.do 论坛专用插件，基于 Discourse 系统'
    };
  }

  /**
   * Linux.do / Discourse 特有的元素查找逻辑
   */
  _findElements() {
    const elements = {
      isEditor: false,
      platform: this.id,
      elements: {}
    };

    // 检查是否是 Linux.do 编辑器页面
    const isLinuxdoEditor = this.urlPatterns.some(pattern => this.matchUrl(window.location.href, pattern));

    if (isLinuxdoEditor) {
      // 查找标题输入框 - Discourse 标准选择器
      elements.elements.title = this.findElementFromSelectors([
        '#reply-title',
        '.title-input input',
        'input[placeholder*="标题"]',
        'input[placeholder*="title"]',
        '.composer-fields input[type="text"]'
      ]);

      // 查找内容编辑器 - Discourse 使用 textarea
      elements.elements.content = this.findElementFromSelectors([
        '.d-editor-input',
        'textarea.d-editor-input',
        '#reply-control .d-editor-input',
        '.d-editor textarea',
        'textarea[aria-label*="content"]'
      ]);

      // 查找分类选择器
      elements.elements.category = this.findElementFromSelectors([
        '.category-chooser',
        '.select-kit-header[data-name="category"]',
        '.category-drop .badge-category'
      ]);

      // 查找标签输入框
      elements.elements.tags = this.findElementFromSelectors([
        '.mini-tag-chooser',
        '.tag-chooser',
        'input.tag-input'
      ]);
    }

    // 验证是否是 Linux.do 编辑器
    elements.isEditor = isLinuxdoEditor && !!(elements.elements.title || elements.elements.content);

    console.log('🔍 Linux.do 编辑器检测结果:', {
      url: window.location.href,
      isLinuxdoEditor,
      title: !!elements.elements.title,
      content: !!elements.elements.content,
      category: !!elements.elements.category,
      tags: !!elements.elements.tags,
      isEditor: elements.isEditor,
      attempt: this.waitAttempts
    });

    return elements;
  }

  /**
   * 智能等待编辑器加载
   * Discourse 编辑器可能需要等待动态加载
   */
  async waitForEditor(maxWaitTime = 10000) {
    console.log('⏳ Linux.do 编辑器智能等待开始...');
    const startTime = Date.now();

    return new Promise((resolve) => {
      const checkEditor = () => {
        this.waitAttempts++;
        const elements = this._findElements();

        // 检查是否找到了可用的编辑器
        if (elements.isEditor && this.isEditorReady(elements.elements)) {
          console.log(`✅ Linux.do 编辑器就绪 (尝试 ${this.waitAttempts} 次)`);
          resolve(elements);
          return;
        }

        // 检查超时
        if (Date.now() - startTime >= maxWaitTime || this.waitAttempts >= this.maxWaitAttempts) {
          console.warn(`⏰ Linux.do 编辑器等待超时 (尝试 ${this.waitAttempts} 次)`);
          resolve(elements); // 即使超时也返回当前结果
          return;
        }

        // 继续等待
        setTimeout(checkEditor, 500);
      };

      checkEditor();
    });
  }

  /**
   * 检查编辑器是否真正准备就绪
   */
  isEditorReady(elements) {
    // 标题输入框存在且可见
    const titleReady = elements.title &&
                      elements.title.offsetParent !== null &&
                      !elements.title.disabled &&
                      !elements.title.readOnly;

    // 内容编辑器存在且可编辑
    const contentReady = elements.content &&
                        elements.content.offsetParent !== null &&
                        !elements.content.disabled &&
                        !elements.content.readOnly;

    return titleReady && contentReady;
  }

  /**
   * Linux.do 特殊的填充逻辑
   */
  async fillContent(data) {
    const elements = await this.findEditorElements(false);

    if (!elements.isEditor) {
      throw new Error(`当前页面不是${this.displayName}编辑器`);
    }

    console.log(`🚀 开始填充 Linux.do 内容`);
    const results = {};

    // 填充标题
    if (data.title && elements.elements.title) {
      console.log('📝 Linux.do：填充标题');
      results.title = await this.fillTitle(elements.elements.title, data.title);
    } else {
      console.warn('⚠️ Linux.do：未找到标题输入框或标题数据');
      results.title = { success: false, error: '未找到标题输入框' };
    }

    // 填充内容 - Linux.do 支持完整 Markdown
    if (data.content && elements.elements.content) {
      console.log('📝 Linux.do：填充 Markdown 内容');

      // 获取原始 Markdown 内容
      let markdownContent = data.originalMarkdown || data.content;

      // 如果有预设，应用开头和结尾内容
      if (data.preset) {
        console.log('🔧 应用发布预设:', data.preset.name);

        // 添加开头内容
        if (data.preset.headerContent) {
          markdownContent = data.preset.headerContent + '\n\n' + markdownContent;
          console.log('✅ 开头内容已添加');
        }

        // 添加结尾内容
        if (data.preset.footerContent) {
          markdownContent = markdownContent + '\n\n' + data.preset.footerContent;
          console.log('✅ 结尾内容已添加');
        }
      }

      results.content = await this.fillContentEditor(elements.elements.content, markdownContent, data);
    } else {
      console.warn('⚠️ Linux.do：跳过内容填充');
      results.content = { success: false, error: '未找到内容编辑器或内容数据' };
    }

    // 执行后处理
    await this.postFillProcess(elements.elements, data, results);

    console.log(`✅ Linux.do 内容填充完成`);
    ZiliuEventBus.emit('platform:fillComplete', {
      platform: this.id,
      results,
      data
    });

    return results;
  }

  /**
   * 填充内容编辑器 - Discourse 使用 textarea
   */
  async fillContentEditor(contentElement, content, data) {
    console.log('📝 填充 Discourse 编辑器内容');

    try {
      // Discourse 使用标准的 textarea 元素
      await this.fillTextarea(contentElement, content);

      return { success: true, value: content, type: 'Discourse' };
    } catch (error) {
      console.error('Linux.do 内容填充失败:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * 填充 textarea
   */
  async fillTextarea(element, content) {
    if (!element || typeof content !== 'string') {
      throw new Error('无效的元素或内容');
    }

    // 确保元素可见和可编辑
    element.focus();
    element.scrollIntoView({ behavior: 'smooth', block: 'center' });

    await this.delay(200);

    // 清空并设置新内容
    element.value = '';
    element.value = content;

    // 触发必要的事件以让 Discourse 检测到变化
    const events = ['input', 'change', 'blur'];
    for (const eventType of events) {
      const event = new Event(eventType, { bubbles: true });
      element.dispatchEvent(event);
      await this.delay(100);
    }

    // Discourse 特有的事件
    try {
      const inputEvent = new InputEvent('input', {
        inputType: 'insertText',
        data: content,
        bubbles: true
      });
      element.dispatchEvent(inputEvent);
    } catch (e) {
      console.warn('触发 InputEvent 失败:', e);
    }

    await this.delay(300);
  }

  /**
   * Linux.do 平台的特殊标题填充
   */
  async fillTitle(titleElement, title) {
    console.log('📝 填充 Linux.do 标题:', title);

    try {
      // 确保元素可见和可编辑
      titleElement.focus();
      titleElement.scrollIntoView({ behavior: 'smooth', block: 'center' });

      await this.delay(200);

      // 清空并设置新标题
      titleElement.value = '';
      titleElement.value = title;

      // 触发必要的事件
      const events = ['input', 'change', 'blur', 'keyup'];
      for (const eventType of events) {
        const event = new Event(eventType, { bubbles: true });
        titleElement.dispatchEvent(event);
        await this.delay(100);
      }

      // 验证标题是否设置成功
      if (titleElement.value !== title) {
        console.warn('Linux.do 标题设置可能失败，尝试重新设置');

        // 重试一次
        await this.delay(500);
        titleElement.value = title;
        titleElement.dispatchEvent(new Event('input', { bubbles: true }));
      }

      return { success: true, value: title };
    } catch (error) {
      console.error('Linux.do 标题填充失败:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Linux.do 平台的后处理
   */
  async postFillProcess(elements, data, results) {
    console.log('🔧 Linux.do 平台后处理...');

    // 如果标题和内容都填充成功，显示提示
    if (results.title?.success && results.content?.success) {
      console.log('✅ Linux.do 内容填充完成，建议检查分类和标签');

      // 尝试聚焦到分类选择器（如果存在）
      if (elements.category) {
        try {
          await this.delay(500);
          elements.category.click();
          console.log('💡 已打开分类选择器，请选择合适的分类');
        } catch (e) {
          console.warn('打开分类选择器失败:', e);
        }
      }
    }

    // 发送 Linux.do 特有的事件
    ZiliuEventBus.emit('linuxdo:fillComplete', {
      results,
      waitAttempts: this.waitAttempts
    });

    // 重置等待计数
    this.waitAttempts = 0;
  }

  /**
   * 重写 findEditorElements 以支持智能等待
   */
  async findEditorElements(useCache = true) {
    // Linux.do 编辑器可能需要等待
    const needsWait = this.specialHandling?.waitForEditor &&
                     (!this.lastSuccessfulCheck || Date.now() - this.lastSuccessfulCheck > 10000);

    if (needsWait) {
      const result = await this.waitForEditor();

      // 如果智能等待成功找到编辑器，记录成功时间并返回
      if (result.isEditor) {
        this.lastSuccessfulCheck = Date.now();
        return result;
      }
    }

    // 调用父类方法
    const result = super.findEditorElements(useCache);

    // 如果父类方法成功，也记录成功时间
    if (result.isEditor) {
      this.lastSuccessfulCheck = Date.now();
    }

    return result;
  }

  /**
   * 复制文章内容 - Linux.do 使用 Markdown
   */
  async copyArticleContent(articleId) {
    try {
      console.log(`📋 Linux.do 平台复制内容，文章ID:`, articleId);

      // 获取文章的原始 Markdown 内容
      const response = await window.ZiliuApiService.articles.get(articleId, 'raw');
      if (!response.success) {
        throw new Error(response.error || '获取文章内容失败');
      }

      const articleData = response.data;
      if (!articleData.content) {
        throw new Error('文章内容为空');
      }

      // 使用原始 Markdown 内容
      let contentToCopy = articleData.content;

      // 获取当前选中的预设并包含预设内容
      const currentPreset = window.ZiliuApp?.getSelectedPreset?.();
      console.log(`📋 Linux.do 复制：获取当前预设:`, currentPreset);

      if (currentPreset) {
        // 添加开头内容
        if (currentPreset.headerContent) {
          console.log(`📋 Linux.do 复制：添加预设开头内容`);
          contentToCopy = currentPreset.headerContent + '\n\n' + contentToCopy;
        }

        // 添加结尾内容
        if (currentPreset.footerContent) {
          console.log(`📋 Linux.do 复制：添加预设结尾内容`);
          contentToCopy += '\n\n' + currentPreset.footerContent;
        }
      }

      console.log(`📋 Linux.do 复制：最终内容长度:`, contentToCopy.length);

      // 复制到剪贴板
      await navigator.clipboard.writeText(contentToCopy);

      return {
        success: true,
        content: contentToCopy,
        format: 'markdown',
        message: 'Markdown 内容已复制到剪贴板（包含预设内容）！'
      };
    } catch (error) {
      console.error(`Linux.do 复制失败:`, error);
      return {
        success: false,
        error: error.message,
        message: '复制失败: ' + error.message
      };
    }
  }
}

// 配置驱动的自动注册
if (window.ZiliuPlatformRegistry && window.ZiliuPluginConfig) {
  const linuxdoConfig = window.ZiliuPluginConfig.platforms.find(p => p.id === 'linuxdo');

  if (linuxdoConfig && linuxdoConfig.enabled) {
    const shouldRegister = linuxdoConfig.urlPatterns.some(pattern => {
      try {
        const escapedPattern = pattern.replace(/[.+^${}()|[\]\\?]/g, '\\$&').replace(/\*/g, '.*');
        const regex = new RegExp('^' + escapedPattern + '$', 'i');
        return regex.test(window.location.href);
      } catch (e) {
        return false;
      }
    });

    if (shouldRegister) {
      console.log('🔧 注册 Linux.do 专用插件（配置驱动）');
      const linuxdoPlugin = new LinuxdoPlatformPlugin(linuxdoConfig);
      ZiliuPlatformRegistry.register(linuxdoPlugin);
    }
  }
}

window.LinuxdoPlatformPlugin = LinuxdoPlatformPlugin;
